function estimateCalories(food, grams) {
  const caloriesPer100g = {
    // Common foods (can be expanded more)
    apple: 52, banana: 89, orange: 47, strawberry: 32,
    grapes: 69, mango: 60, pizza: 266, burger: 295, fries: 365,
    chicken: 165, beef: 250, salmon: 208, egg: 143,
    rice: 130, bread: 265, pasta: 131, potato: 77,
    chocolate: 546, chips: 536, cheese: 402, milk: 42,
    yogurt: 59, lettuce: 15, tomato: 18, broccoli: 55, carrot: 41
  };

  const foodKey = food.toLowerCase().trim();
  const base = caloriesPer100g[foodKey];

  if (!base) {
    console.warn(`Unknown food: ${food}. Using 150 kcal/100g as estimate.`);
    return Math.round(150 * (grams / 100));
  }

  return Math.round(base * (grams / 100));
}
